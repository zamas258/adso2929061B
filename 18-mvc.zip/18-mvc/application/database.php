<?php
    abstract class DataBase {
        
    }