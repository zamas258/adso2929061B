<?php
    class Model extends DataBase {

    }