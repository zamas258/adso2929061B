<?php
    require_once 'application/mvc.php';